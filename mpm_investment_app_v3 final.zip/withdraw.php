
<!DOCTYPE html>
<html>
<head>
  <title>MPM Investment - Withdraw</title>
</head>
<body style="font-family:Arial;background:#0d1b2a;color:#fff;">
  <h2>Withdraw</h2>
  <form>
    <input type="text" placeholder="Amount"><br><br>
    <input type="text" placeholder="Phone Number"><br><br>
    <button type="submit">Request Withdraw</button>
  </form>
</body>
</html>
