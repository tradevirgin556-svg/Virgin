
<!DOCTYPE html>
<html>
<head>
  <title>MPM Investment - Packages</title>
</head>
<body style="font-family:Arial;background:#0d1b2a;color:#fff;">
  <h2>Investment Packages</h2>
  <div style="margin:20px;padding:10px;border:1px solid gold;">
    <h3>Bronze</h3>
    <p>Capital: UGX 55,000</p>
    <p>Daily Return: 8%</p>
    <button>Invest</button>
  </div>
  <div style="margin:20px;padding:10px;border:1px solid gold;">
    <h3>Silver</h3>
    <p>Capital: UGX 210,000</p>
    <p>Daily Return: 8%</p>
    <button>Invest</button>
  </div>
  <div style="margin:20px;padding:10px;border:1px solid gold;">
    <h3>Gold</h3>
    <p>Capital: UGX 530,000</p>
    <p>Daily Return: 8%</p>
    <button>Invest</button>
  </div>
</body>
</html>
