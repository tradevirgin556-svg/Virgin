
<!DOCTYPE html>
<html>
<head>
  <title>MPM Investment - Deposit</title>
</head>
<body style="font-family:Arial;background:#0d1b2a;color:#fff;">
  <h2>Deposit</h2>
  <p>Send money to <b>+256765781511</b> then enter Transaction Number below:</p>
  <form>
    <input type="text" placeholder="Transaction Number">
    <button type="submit">Submit</button>
  </form>
</body>
</html>
