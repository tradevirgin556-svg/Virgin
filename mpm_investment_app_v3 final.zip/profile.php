
<!DOCTYPE html>
<html>
<head>
  <title>MPM Investment - Profile</title>
</head>
<body style="font-family:Arial;background:#0d1b2a;color:#fff;">
  <h2>Profile</h2>
  <div>Name: Demo User</div>
  <div>Phone: 07XXXXXXXX</div>
  <div>Email: demo@example.com</div>
  <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
