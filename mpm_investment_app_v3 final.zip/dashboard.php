
<!DOCTYPE html>
<html>
<head>
  <title>MPM Investment - Dashboard</title>
</head>
<body style="font-family:Arial;background:#0d1b2a;color:#fff;">
  <h2>Dashboard</h2>
  <div>Wallet Balance: UGX 0</div>
  <div>Total Investment: UGX 0</div>
  <a href="packages.php">View Packages</a> |
  <a href="deposit.php">Deposit</a> |
  <a href="withdraw.php">Withdraw</a> |
  <a href="profile.php">Profile</a>
</body>
</html>
